<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Amqp\Model;

/**
 * {@inheritdoc}
 *
 * @deprecated 100.2.0
 */
class Queue extends \Magento\Framework\Amqp\Queue
{

}
